package com.company;

import java.sql.*;
//数据库类
public class db {
    // 远程数据库："jdbc:mysql://121.15.171.90:3306/ossec"
    // 本地数据库： "jdbc:mysql://127.0.0.1:3306/mydb?serverTimezone=UTC"
    public static String URL = "jdbc:mysql://127.0.0.1:3306/ossec?serverTimezone=UTC";
    public static String USER = "root";
    public static String PASSWORD = "990904";
    public static Connection conn = null;
    public static String ip=null;
    public static String ruleid=null;
    //1.连接数据库
    public static String link()
    {
        //1.加载数据库驱动
        try {
            //这里不用更改，如果你要连的不是mysql的话再换这个括号内的代码
            Class.forName("com.mysql.cj.jdbc.Driver");
            //System.out.println("驱动加载成功！");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            //System.out.println("驱动加载失败！");
            e.printStackTrace();
            return "驱动加载失败！";
        }
        //2.连接数据库
        try {
            conn =  DriverManager.getConnection(URL, USER, PASSWORD);//把上面的三个属性传过来，应该就连接成功了，不成功的话应该就是你的账号密码不正确
            //System.out.println("数据库连接成功！");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            //System.out.println("连接失败！");
            return "数据库连接失败！";
        }
        return "数据库连接成功！";
    }

    public static String SSHDetect()
    {
        try{
            Statement st=conn.createStatement();
            detectSSHAttack ssh=new detectSSHAttack();
            String sql="select rule_id,src_ip from alert where level>5";
            ResultSet rs=st.executeQuery(sql);
//            ssh.detect("127.0.0.1","5706");
//            ssh.detect("127.0.0.1","5712");
            while(rs.next()){
                if(rs.getObject("src_ip").toString()==null) ip="unknown ip";
                else ip=rs.getObject("src_ip").toString();
                ruleid=rs.getObject("rule_id").toString();
                ssh.detect(ip,ruleid);
            }
            ssh.SSHprint();
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return "OSSec detect fail！";
        }
        return "ok";
    }
    public static String OSSecDetect()
    {
        try{
            Statement st=conn.createStatement();
            detectOSSecAttack os=new detectOSSecAttack();
            String sql="select rule_id,src_ip from alert where level>5";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                if(rs.getObject("src_ip").toString().equals("(null)")) ip="unknown ip";
                else ip=rs.getObject("src_ip").toString();
                ruleid=rs.getObject("rule_id").toString();
                os.detect(ip,ruleid);
            }
            os.OSSecprint();
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return "OSSec detect fail！";
        }
        return "ok";
    }
    public static String ArpDetect()
    {
        try{
            Statement st=conn.createStatement();
            detectArpAttack arp=new detectArpAttack();
            String sql="select rule_id,src_ip from alert where level>5";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                if(rs.getObject("src_ip").toString().equals("(null)")) ip="unknown ip";
                else ip=rs.getObject("src_ip").toString();
                ruleid=rs.getObject("rule_id").toString();
                arp.detect(ip,ruleid);
            }
            arp.Arpprint();
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return "OSSec detect fail！";
        }
        return "ok";
    }
    public static String PriDetect()
    {
        try{
            Statement st=conn.createStatement();
            detectPriAttack pri=new detectPriAttack();
            String sql="select rule_id,src_ip from alert where level>5";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                if(rs.getObject("src_ip").toString().equals("(null)")) ip="unknown ip";
                else ip=rs.getObject("src_ip").toString();
                ruleid=rs.getObject("rule_id").toString();
                pri.detect(ip,ruleid);
            }
            pri.Priprint();
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return "OSSec detect fail！";
        }
        return "ok";
    }

    public static String SyslogDetect()
    {
        try{
            Statement st=conn.createStatement();
            detectSysLogAttack syslog=new detectSysLogAttack();
            String sql="select rule_id,src_ip from alert where level>5";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                if(rs.getObject("src_ip").toString().equals("(null)")) ip="unknown ip";
                else ip=rs.getObject("src_ip").toString();
                ruleid=rs.getObject("rule_id").toString();
                syslog.detect(ip,ruleid);
            }
            syslog.SysLogPrint();
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return "OSSec detect fail！";
        }
        return "ok";
    }

}

