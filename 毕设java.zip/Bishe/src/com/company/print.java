package com.company;

public class print {
    //网络扫描
    public final Integer netscan=0x0000001;
    //多次认证失败
    public final Integer multiAuths=0x0000010;
    //多次认证失败后成功登录了
    public final Integer mutiThenSucc=0x0000100;
    //发现病毒
    public final Integer virus=0x0001000;
    //发现攻击企图
    public final Integer exploitAtt=0x0010000;
    //发现已经成功的攻击
    public final Integer exploitSucc=0x0100000;
    //成功提示权限
    public final Integer elevaPri=0x1000000;
    public String printThreat(Integer temp)
    {
        String mes="";
        //网络扫描
        if((temp&netscan)!=0)
        {
            mes+="netscan_step1,";
        }
        //多次认证失败
        if((temp&multiAuths)!=0)
        {
            mes+="multiAuthsFail_step1,";
        }
        //多次认证失败后成功登录了
        if((temp&mutiThenSucc)!=0)
        {
            mes+="mutiThenSucc_step2,";
        }
        //发现病毒
        if((temp&virus)!=0)
        {
            mes+="findVirus_step2,";
        }
        //发现攻击企图
        if((temp&exploitAtt)!=0)
        {
            mes+="exploitAttempt_step2,";
        }
        //发现已经成功的攻击
        if((temp&exploitSucc)!=0)
        {
            mes+="exploitSucc_step3,";

        }
        //成功提示权限
        if((temp&elevaPri)!=0)
        {
            mes+="elevaPrileages_step4,";
        }
        return mes;
    }
}
