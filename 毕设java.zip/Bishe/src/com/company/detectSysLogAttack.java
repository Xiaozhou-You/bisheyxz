package com.company;

import java.util.HashMap;
import java.util.Map;

public class detectSysLogAttack {

    public long attacktimes=0;
    //配置改变
    public final Integer ConfigChanged0=0b0000001;
    //新用户
    public final Integer NewUserLogSys0=0b0000010;
    //磁盘问题
    public final Integer DiskspaceProblem1=0b0000100;
    //嗅探接口模式
    public final Integer InterfaceToSniffer1=0b0001000;
    //非法连接登录
    public final Integer IllegelLogConn2=0b0010000;
    //多次失败登录
    public final Integer multiAuths2=0b0100000;
    //DDOS
    public final Integer DDOSAttack2=0b1000000;
    //OSError
    public final Integer OSError3=0b10000000;
    //String记录IP,Integer记录攻击情况
    Map<String,Integer> detectGoal=new HashMap<String,Integer>();
    public String detect(String ip,String rule)
    {
        Integer temp=0x0;
        if(detectGoal.containsKey(ip))
        {
            temp=detectGoal.get(ip);
        }
        while(true)
        {
            //配置改变
            if(rule.equals("2934")|rule.equals("2932")|rule.equals("2933")|rule.equals("2952")|rule.equals("2903"))
            {
                temp=temp|ConfigChanged0;
                detectGoal.put(ip,temp);
                break;
            }
            //新用户
            if(rule.equals("5901")|rule.equals("5902")|rule.equals("5904"))
            {
                temp=temp|NewUserLogSys0;
                detectGoal.put(ip,temp);
                break;
            }
            //磁盘问题
            if(rule.equals("1007"))
            {
                temp=temp|DiskspaceProblem1;
                detectGoal.put(ip,temp);
                break;
            }
            //嗅探接口模式
            if(rule.equals("5104"))
            {
                temp=temp|InterfaceToSniffer1;
                detectGoal.put(ip,temp);
                break;
            }
            //非法连接登录
            if(rule.equals("2504")|rule.equals("2551")|rule.equals("5404"))
            {
                temp=temp|IllegelLogConn2;
                detectGoal.put(ip,temp);
                break;
            }
            //多次失败登录
            if(rule.equals("2502")|rule.equals("5302"))
            {
                temp=temp|multiAuths2;
                detectGoal.put(ip,temp);
                break;
            }
            //DDOS
            if(rule.equals("2301")|rule.equals("5103"))
            {
                temp=temp|DDOSAttack2;
                detectGoal.put(ip,temp);
                break;
            }
            //OSError
            if(rule.equals("1003")|rule.equals("5108")|rule.equals("2937")|rule.equals("2939"))
            {
                temp=temp|OSError3;
                detectGoal.put(ip,temp);
                break;
            }

            //不是要检测的rule
            return "no";
        }
        //记录攻击次数
        if(temp!=0) attacktimes++;
        //检测到了对应的攻击
        return "yes";
    }
    public String SysLogPrint()
    {
        String ip=null;
        String mes=null;
        long times=0;
        for(Map.Entry<String,Integer> entry:detectGoal.entrySet())
        {
            times++;
            ip=entry.getKey();
            mes=SysLogMes(entry.getValue());
            System.out.println("IP:"+ip+mes);
            //System.out.println(mes);
        }
        System.out.println("共有"+times+"个ip,"+"造成主机了"+attacktimes+"次较为严重的警告");
        System.out.println("Syslog服务检测结束");
        return "ok";
    }

    public  String SysLogMes(Integer temp)
    {
        String mes="";
        boolean f0=false;
        boolean f1=false;
        boolean f2=false;
        boolean f3=false;
        if(temp==0) return "";
        //ConfigChanged
        if((temp&ConfigChanged0)!=0)
        {
            mes="ConfigChanged_step0,"+mes;
            f0=true;
        }
        //NewUserLogSys
        if((temp&NewUserLogSys0)!=0)
        {
            f0=true;
            mes="NewUserLogSys_step0,"+mes;
        }
        if(f0)
            mes="\nSysLogAttackStep0:"+mes;
        //磁盘问题
        if((temp&DiskspaceProblem1)!=0)
        {
            f1=true;
            mes="DiskspaceProblem1_step1,"+mes;
        }
        //InterfaceToSniffer
        if((temp&InterfaceToSniffer1)!=0)
        {
            f1=true;
            mes="InterfaceToSniffer_step1,"+mes;
        }
        if(f1)
            mes="\nSysLogAttackStep1:"+mes;
        //IllegelLogConn
        if((temp&IllegelLogConn2)!=0)
        {
            f2=true;
            mes="IllegelLogConn_step2"+mes;
        }
        //多次登录失败
        if((temp&multiAuths2)!=0)
        {
            f2=true;
            mes="multiAuths_step2"+mes;
        }
        //ddos or death ping
        if((temp&DDOSAttack2)!=0)
        {
            f2=true;
            mes="DDOSAttack_step2"+mes;
        }
        if(f2)
            mes="\nSysLogAttackStep2:"+mes;
        //os come up errors
        if((temp&OSError3)!=0)
        {
            f3=true;
            mes="OSError_step3!!!"+mes;
        }
        if(f3)
            mes="SysLogAttackStep3:"+mes;
        return mes;
    }
    public Map<String,Integer> get_map()
    {
        return detectGoal;
    }

}
