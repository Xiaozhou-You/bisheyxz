package com.company;

import java.util.HashMap;
import java.util.Map;

public class detectArpAttack {
    public long attacktimes=0;
    //网络扫描
    public final Integer netScan0=0x000001;
    //发现新主机加入arp表
    public final Integer NewHostDected0=0x000010;
    //arp表出现权限问题
    public final Integer wrongPermission1=0x000100;
    //ARP攻击企图
    public final Integer arpAttackAttempt2=0x001000;
    //arp表改变
    public final Integer arpChanged2=0x010000;
    //arp表改变频繁
    public final Integer getArpChangedOffen3=0x100000;
    //String记录IP,Integer记录攻击情况
    public Map<String,Integer> detectGoal=new HashMap<String,Integer>();

    public String detect(String ip,String rule)
    {
        Integer temp=0x0;
        if(detectGoal.containsKey(ip))
        {
            temp=detectGoal.get(ip);
        }
        while(true)
        {
            //网络扫描
            if(rule.equals("40601"))
            {
                temp=temp|netScan0;
                detectGoal.put(ip,temp);
                break;
            }
            //发现新主机加入arp表
            if(rule.equals("7201"))
            {
                temp=temp|NewHostDected0;
                detectGoal.put(ip,temp);
                break;
            }
            //arp表出现权限问题
            if(rule.equals("7207"))
            {
                temp=temp|wrongPermission1;
                detectGoal.put(ip,temp);
                break;
            }
            //ARP攻击企图
            if(rule.equals("7209"))
            {
                temp=temp|arpAttackAttempt2;
                detectGoal.put(ip,temp);
                break;
            }
            //arp表改变
            if(rule.equals("7204"))
            {
                temp=temp|arpChanged2;
                detectGoal.put(ip,temp);
                break;
            }
           //arp表改变频繁
            if(rule.equals("7202"))
            {
                temp=temp|getArpChangedOffen3;
                detectGoal.put(ip,temp);
                break;
            }
            if(temp!=0) attacktimes++;
            //不是要检测的rule
            return "no";
        }
        //检测到了对应的攻击
        return "yes";
    }
    public String Arpprint()
    {
        String ip=null;
        String mes=null;
        long times=0;
        for(Map.Entry<String,Integer> entry:detectGoal.entrySet())
        {
            times++;
            ip=entry.getKey();
            mes=ArpMes(entry.getValue());
            System.out.println("IP:"+ip+mes);
            //System.out.println(mes);
        }
        System.out.println("共有"+times+"个ip,"+"造成主机了"+attacktimes+"次较为严重的警告");
        System.out.println("ARP服务检测结束");
        return "ok";
    }
    public  String ArpMes(Integer temp)
    {
        String mes="";
        boolean f0=false;
        boolean f1=false;
        boolean f2=false;
        boolean f3=false;
        if(temp==0) return "";
        //网络扫描
        if((temp&netScan0)!=0)
        {
            mes="netScan0,"+mes;
            f0=true;
        }

        if((temp&NewHostDected0)!=0)
        {
            f1=true;
            mes="NewHostDected_step0,"+mes;
        }
        if(f0)
            mes="\nArpAttackStep0:"+mes;
        if((temp&wrongPermission1)!=0)
        {
            f1=true;
            mes="wrongPermission_step1,"+mes;
        }
        if(f1)
            mes="\nArpAttackStep1:"+mes;
        if((temp&arpAttackAttempt2)!=0)
        {
            f2=true;
            mes="arpAttackAttempt_step2,"+mes;
        }

        if((temp&arpChanged2)!=0)
        {
            f2=true;
            mes="arpWatchChanged_step2,"+mes;
        }
        if(f2)
            mes="\nArpAttackStep2:"+mes;
        if((temp&getArpChangedOffen3)!=0)
        {
            f3=true;
            mes="getArpChangedOffen_step3,"+mes;
        }
        if(f3)
            mes="\nArpAttackStep3:"+mes;

        return mes;
    }
    public Map<String,Integer> getMap()
    {
        return detectGoal;
    }
}
