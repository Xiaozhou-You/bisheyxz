package com.company;

import java.util.HashMap;
import java.util.Map;

public class detectSSHAttack {
    public long attacktimes=0;
    //网络扫描
    public final Integer SSHScan0=0b0000001;
    //多次认证失败
    public final Integer multiAuths1=0b0000010;
    //疑似ssh攻击
    public final Integer possibleAttack1=0b0000100;
    //爆破攻击
    public final Integer bruteAttack2=0b0001000;
    //发现攻击企图
    public final Integer exploitAtt2=0b0010000;
    //无效用户频繁登录
    public final Integer denyUserLogin2=0b0100000;
    //ssh攻击成功
    public final Integer SSHAttack3=0b1000000;
    //String记录IP,Integer记录攻击情况
    Map<String,Integer> detectGoal=new HashMap<String,Integer>();
//    public void detectSSHAttack(int flag)
//    {
//        exist=flag;
//    }
    public String detect(String ip,String rule)
    {
        Integer temp=0x0;
        if(detectGoal.containsKey(ip))
        {
            temp=detectGoal.get(ip);
        }
        while(true)
        {
            //ssh网络扫描
            if(rule.equals("40111")|rule.equals("5706")|rule.equals("5713")|rule.equals("5747")|rule.equals("5731")|rule.equals("5748"))
            {
                temp=temp|SSHScan0;
                detectGoal.put(ip,temp);
                break;
            }
            //多次认证失败
            if(rule.equals("5758"))
            {
                temp=temp|multiAuths1;
                detectGoal.put(ip,temp);
                break;
            }
            //疑似ssh攻击
            if(rule.equals("5701"))
            {
                temp=temp|possibleAttack1;
                detectGoal.put(ip,temp);
                break;
            }
            //发现攻击企图
            if(rule.equals("5703")|rule.equals("5705"))
            {
                temp=temp|exploitAtt2;
                detectGoal.put(ip,temp);
                break;
            }
            //爆破攻击
            if(rule.equals("5712")|rule.equals("5720"))
            {
                temp=temp|bruteAttack2;
                detectGoal.put(ip,temp);
                break;
            }
            //无效用户频繁登录
            if(rule.equals("5719"))
            {
                temp=temp|denyUserLogin2;
                detectGoal.put(ip,temp);
                break;
            }
            //ssh攻击成功
            if(rule.equals("5707")|rule.equals("5714"))
            {
                temp=temp|SSHAttack3;
                detectGoal.put(ip,temp);
                break;
            }
            //不是要检测的rule
            return "no";
        }
        if(temp!=0) attacktimes++;
        //检测到了对应的攻击
        return "yes";
    }

    public String SSHprint()
    {
        String ip=null;
        String mes=null;
        long times=0;
        for(Map.Entry<String,Integer> entry:detectGoal.entrySet())
        {
            times++;
            ip=entry.getKey();
            mes=SSHMes(entry.getValue());
            System.out.println("IP:"+ip+mes);
            //System.out.println(mes);
        }
        System.out.println("共有"+times+"个ip,"+"造成主机了"+attacktimes+"次较为严重的警告");
        System.out.println("SSH服务检测结束");
        return "ok";
    }
    public  String SSHMes(Integer temp)
    {
        String mes="";
        boolean f0=false;
        boolean f1=false;
        boolean f2=false;
        boolean f3=false;
        if(temp==0) return "";
        //网络扫描
        if((temp&SSHScan0)!=0)
        {
            mes="SSHScan_step0,"+mes;
            f0=true;
        }
        if(f0)
        mes="\nSSHAttackStep0:"+mes;
        //多次认证失败
        if((temp&multiAuths1)!=0)
        {
            f1=true;
            mes="multiAuthsFail_step1,"+mes;
        }
        //多次认证失败后成功登录了
        if((temp&possibleAttack1)!=0)
        {
            f1=true;
            mes="possibleAttackOnSSHServer_step1,"+mes;
        }
        if(f1)
        mes="\nSSHAttackStep1:"+mes;
        //发现攻击企图
        if((temp&exploitAtt2)!=0)
        {
            f2=true;
            mes="exploitAttemp_step2,"+mes;
        }
        //bruteAttack
        if((temp&bruteAttack2)!=0)
        {
            f2=true;
            mes="bruteAttack_step2,"+mes;
        }
        //denyUserLogin
        if((temp&denyUserLogin2)!=0)
        {
            f2=true;
            mes="denyUserLogin_step2,"+mes;
        }
        if(f2)
        mes="\nSSHAttackStep2:"+mes;
        //ssh攻击出现
        if((temp&SSHAttack3)!=0)
        {
            f3=true;
            mes="SSHAttack_step4!!!"+mes;
        }
        if(f3)
        mes="SSHAttackStep3:"+mes;
        return mes;
    }
    public Map<String,Integer> get_map()
    {
        return detectGoal;
    }
}
