package com.company;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        db d = null;
        int detect = 3;
        Scanner s = new Scanner(System.in);
        d.link();              //0.连接数据库

        while (true) {
            System.out.println("choose a object what you want to detect：");
            System.out.println("1.ossec");
            System.out.println("2.arp");
            System.out.println("3.ssh");
            System.out.println("4.privileage");
            System.out.println("5.syslog");
            System.out.println("input 0 for quit");
            System.out.println("please input a number:");
            detect = s.nextInt();
            switch (detect) {
                case 1:
                    System.out.println("ossec detecting...");
                    d.OSSecDetect();      //1.检测ossec
                    break;
                case 2:
                    System.out.println("arp detecting...");
                    d.ArpDetect();          //2.检测Arp
                    break;
                case 3:
                    System.out.println("ssh detecting...");
                    d.SSHDetect();
                    break;
                case 4:
                    System.out.println("privileages detecting...");
                    d.PriDetect();
                    break;
                case 5:
                    System.out.println("syslog detecting...");
                    d.SyslogDetect();
                    break;
                default:
                    System.out.println("input illegel, so input again");
                    break;
            }
            if (detect == 0) break;
            System.out.println("------------------------------------");
        }
        System.out.println("byebye!");
    }
}






















//一些测试，不用理会
//        1.数据库测试代码
//        String mes=null;
//        System.out.println("this is xiaozhou bishe!");
//        db mysql = null;
//        mes=mysql.link();
//        System.out.println(mes);
//        2.二进制测试代码
//        int a=0x0010;
//        int b=0x0001;
//        System.out.println(a&b);
//        3.Map测试代码
//        Map<String,Integer> test=new HashMap<String,Integer>();
//        test.put("hello",0x0010);
//        test.put("yxz",0x0001);
//        String a="yxz";
//        if(test.containsKey(a))
//        {
//            test.put(a,0x11);
//        }
//        for(Map.Entry<String,Integer> entry:test.entrySet())
//        {
//            System.out.println(entry.getKey()+":"+entry.getValue());
//        }
//        4.字符串截取
//        String a="afeegegefrom 192.168.10.103";
//        int aa=a.indexOf("from");
//        System.out.println(aa);
//        String s=a.substring(aa+5,a.length());
//        System.out.println(s);
