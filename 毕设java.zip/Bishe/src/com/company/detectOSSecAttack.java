package com.company;

import java.util.HashMap;
import java.util.Map;

public class detectOSSecAttack {
    public long attacktimes=0;
    //监听的端口状态改变
    public final Integer portStatusChanged0=0b0000001;
    //文件检验和改变
    public final Integer checksumChanged0=0b0000010;
    //主机相关信息改变
    public final Integer HostinfomationChanged0=0b0000100;
    //出现易受攻击的文件
    public final Integer vulnerableFiles1=0b0001000;
    //磁盘空间问题
    public final Integer diskspaceProblems1=0b0010000;
    //检测问题
    public final Integer detectProblems1=0b0100000;
    //恶意软件发现
    public final Integer malware2=0b1000000;
    //日志被清空
    public final Integer logCleared2=0b10000000;
    //String记录IP,Integer记录攻击情况
    Map<String,Integer> detectGoal=new HashMap<String,Integer>();
    //    public void detectSSHAttack(int flag)
//    {
//        exist=flag;
//    }
    public String detect(String ip,String rule)
    {
        Integer temp=0x0;
        if(detectGoal.containsKey(ip))
        {
            temp=detectGoal.get(ip);
        }
        while(true)
        {

            if(rule.equals("533"))
            {
                temp=temp|portStatusChanged0;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("550")|rule.equals("551")|rule.equals("552")|rule.equals("553")|rule.equals("553"))
            {
                temp=temp|checksumChanged0;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("580")|rule.equals("581"))
            {
                temp=temp|HostinfomationChanged0;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("519"))
            {
                temp=temp|vulnerableFiles1;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("531"))
            {
                temp=temp|diskspaceProblems1;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("510"))
            {
                temp=temp|detectProblems1;
                detectGoal.put(ip,temp);
                break;
            }

            if(rule.equals("513"))
            {
                temp=temp|malware2;
                detectGoal.put(ip,temp);
                break;
            }
            if(rule.equals("593"))
            {
                temp=temp|logCleared2;
                detectGoal.put(ip,temp);
                break;
            }
            //不是要检测的rule
            return "no";
        }
        if(temp!=0) attacktimes++;
        //检测到了对应的攻击
        return "yes";
    }
    public String OSSecprint()
    {
        String ip=null;
        String mes=null;
        long times=0;
        for(Map.Entry<String,Integer> entry:detectGoal.entrySet())
        {
            times++;
            ip=entry.getKey();
            mes=OSSecMes(entry.getValue());
            System.out.println("IP:"+ip+mes);
            //System.out.println(mes);
        }
        System.out.println("共有"+times+"个ip,"+"造成主机了"+attacktimes+"次较为严重的警告");
        System.out.println("OSSec服务检测结束");
        return "ok";
    }
    public  String OSSecMes(Integer temp)
    {
        String mes="";
        boolean f0=false;
        boolean f1=false;
        boolean f2=false;
        boolean f3=false;
        if(temp==0) return "";

        if((temp&portStatusChanged0)!=0)
        {
            mes="portStatusChanged_step0,"+mes;
            f0=true;
        }

        if((temp&checksumChanged0)!=0)
        {
            f0=true;
            mes="multiAuthsFail_step0,"+mes;
        }

        if((temp&HostinfomationChanged0)!=0)
        {
            f0=true;
            mes="HostinfomationChanged_step0,"+mes;
        }
        if(f0)
            mes="\nOSSecAttackStep0:"+mes;
        //发现攻击企图
        if((temp&vulnerableFiles1)!=0)
        {
            f1=true;
            mes="exploitAttemp_step1,"+mes;
        }

        if((temp&diskspaceProblems1)!=0)
        {
            f1=true;
            mes="diskspaceProblems_step1,"+mes;
        }

        if((temp&detectProblems1)!=0)
        {
            f1=true;
            mes="detectProblems_step1,"+mes;
        }
        if(f1)
            mes="\nOSSecAttackStep1:"+mes;

        if((temp&malware2)!=0)
        {
            f2=true;
            mes="malware_step2!!!"+mes;
        }
        if((temp&logCleared2)!=0)
        {
            f2=true;
            mes="logCleared_step2"+mes;
        }
        if(f2)
            mes="OSSecAttackStep2:"+mes;
        return mes;
    }
    public Map<String,Integer> get_map()
    {
        return detectGoal;
    }
}
