package com.company;

import java.util.HashMap;
import java.util.Map;

public class detectPriAttack {
    public long attacktimes=0;
    //网络扫描
    public final Integer netscan0=0x0000001;
    //多次认证失败
    public final Integer multiAuths1=0x0000010;
    //多次认证失败后成功登录了
    public final Integer mutiThenSucc2=0x0000100;
    //发现病毒
    public final Integer virus2=0x0001000;
    //发现攻击企图
    public final Integer exploitAtt2=0x0010000;
    //发现已经成功的攻击
    public final Integer exploitSucc3=0x0100000;
    //成功提示权限
    public final Integer elevaPri3=0x1000000;
    //String记录IP,Integer记录攻击情况
    Map<String,Integer> detectGoal=new HashMap<String,Integer>();
    public String detect(String ip,String rule)
    {
        Integer temp=0x0;
        if(detectGoal.containsKey(ip))
        {
            temp=detectGoal.get(ip);
        }
        while(true)
        {
            //网络扫描
            if(rule.equals("40601"))
            {
                temp=temp|netscan0;
                detectGoal.put(ip,temp);
                break;
            }
            //多次认证失败
            if(rule.equals("40111"))
            {
                temp=temp|multiAuths1;
                detectGoal.put(ip,temp);
                break;
            }
            //多次认证失败后成功登录了
            if(rule.equals("40112"))
            {
                temp=temp|mutiThenSucc2;
                detectGoal.put(ip,temp);
                break;
            }
            //发现病毒
            if(rule.equals("40113"))
            {
                temp=temp|virus2;
                detectGoal.put(ip,temp);
                break;
            }
            //发现攻击企图
            if(rule.equals("40105")|rule.equals("40106")|rule.equals("40107")|rule.equals("40109"))
            {
                temp=temp|exploitAtt2;
                detectGoal.put(ip,temp);
                break;
            }
            //发现已经成功的攻击
            if(rule.equals("40103")|rule.equals("40104"))
            {
                temp=temp|exploitSucc3;
                detectGoal.put(ip,temp);
                break;
            }
            //成功提示权限
            if(rule.equals("40501"))
            {
                temp=temp|elevaPri3;
                detectGoal.put(ip,temp);
                break;
            }
            //不是要检测的rule
            return "no";
        }
        if(temp!=0) attacktimes++;
        //检测到了对应的攻击
        return "yes";
    }
    public String Priprint()
    {
        String ip=null;
        String mes=null;
        long times=0;
        for(Map.Entry<String,Integer> entry:detectGoal.entrySet())
        {
            times++;
            ip=entry.getKey();
            mes=PriMes(entry.getValue());
            System.out.println("IP:"+ip+mes);
            //System.out.println(mes);
        }
        System.out.println("共有"+times+"个ip,"+"造成主机了"+attacktimes+"次较为严重的警告");
        System.out.println("权限服务检测结束");
        return "ok";
    }
    public  String PriMes(Integer temp)
    {
        String mes="";
        boolean f0=false;
        boolean f1=false;
        boolean f2=false;
        boolean f3=false;
        if(temp==0) return "";
        //网络扫描
        if((temp&netscan0)!=0)
        {
            mes="netScan_step0,"+mes;
            f0=true;
        }
        if(f0)
            mes="\nPriAttackStep0:"+mes;
        if((temp&multiAuths1)!=0)
        {
            f1=true;
            mes="multiAuths_step1,"+mes;
        }
        if(f1)
            mes="\nPriAttackStep1:"+mes;
        if((temp&mutiThenSucc2)!=0)
        {
            f1=true;
            mes="mutiThenSucc_step1,"+mes;
        }

        if((temp&virus2)!=0)
        {
            f2=true;
            mes="virus_step2,"+mes;
        }

        if((temp&exploitAtt2)!=0)
        {
            f2=true;
            mes="exploitAtt_step2,"+mes;
        }
        if(f2)
            mes="\nPriAttackStep2:"+mes;
        if((temp&exploitSucc3)!=0)
        {
            f3=true;
            mes="exploitSucc_step3,"+mes;
        }
        if((temp&elevaPri3)!=0)
        {
            f3=true;
            mes="elevaPri_step3,"+mes;
        }
        if(f3)
            mes="\nPriAttackStep3:"+mes;
        return mes;
    }
    public Map<String,Integer> get_map()
    {
        return detectGoal;
    }
}
