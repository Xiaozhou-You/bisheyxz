package com.company;

public class dbData {
    public String ip=null;//ip
    public String rule=null;//攻击代号
    public String date=null;//日期
    public String location=null;//攻击发起地点
    public long timestamp=0;//时间戳
    public void add(String IP,String RULE,String DATE,long TIMESTAMP,String LOCATE)
    {
        ip=IP;
        rule=RULE;
        date=DATE;
        location=LOCATE;
        timestamp=TIMESTAMP;
    }
    public String getIp()
    {
        return ip;
    }
    public String getRule()
    {
        return rule;
    }
    public String getDate()
    {
        return date;
    }
    public long getTimestamp()
    {
        return timestamp;
    }
    public String getLocation()
    {
        return location;
    }
}
