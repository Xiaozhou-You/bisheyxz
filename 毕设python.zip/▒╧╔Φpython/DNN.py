# train the network and use the model to predict the test set
import tensorflow as tf
import numpy as np
import csv, os, random
# Hyper Parameters
LEARNING_RATE = 0.0001
BATCH_SIZE = 32
DATA_DIM = 41
NUM_HIDDEN1_NODES = 32
NUM_HIDDEN2_NODES = 64
NUM_HIDDEN3_NODES = 64
OUTPUT_DIM = 5
MODEL_SAVE_PATH = './model/'
MODEL_NAME = 'kdd_model'
KEEP_PROB = 0.5


class DNN():
    def __init__(self):
        self.learning_rate = LEARNING_RATE
        self.batch_size = BATCH_SIZE
        self.x_input = tf.placeholder(dtype=tf.float32, shape=[None, DATA_DIM])
        self.target = tf.placeholder(dtype=tf.int32, shape=[None])
        self.train_step = tf.Variable(0, trainable=False)

        self.init_data()
        self.create_DNN()
        self.build_loss()

        self.sess = tf.Session()
        self.sess.run(tf.global_variables_initializer())

        self.ckpt = tf.train.get_checkpoint_state(MODEL_SAVE_PATH)
        self.saver = tf.train.Saver()
        self.train_start = 0
        if self.ckpt and self.ckpt.model_checkpoint_path:
            self.saver.restore(self.sess, self.ckpt.model_checkpoint_path)
            self.train_start = self.sess.run(self.train_step)

    def create_DNN(self):
        w1 = tf.Variable(tf.truncated_normal(dtype=tf.float32, shape=[DATA_DIM, NUM_HIDDEN1_NODES], stddev=0.1))
        b1 = tf.Variable(tf.constant(0.1, dtype=tf.float32, shape=[NUM_HIDDEN1_NODES]))
        w2 = tf.Variable(
            tf.truncated_normal(dtype=tf.float32, shape=[NUM_HIDDEN1_NODES, NUM_HIDDEN2_NODES], stddev=0.1))
        b2 = tf.Variable(tf.constant(0.1, dtype=tf.float32, shape=[NUM_HIDDEN2_NODES]))
        w3 = tf.Variable(
            tf.truncated_normal(dtype=tf.float32, shape=[NUM_HIDDEN2_NODES, NUM_HIDDEN3_NODES], stddev=0.1))
        b3 = tf.Variable(tf.constant(0.1, dtype=tf.float32, shape=[NUM_HIDDEN3_NODES]))
        w4 = tf.Variable(tf.truncated_normal(dtype=tf.float32, shape=[NUM_HIDDEN3_NODES, OUTPUT_DIM], stddev=0.1))
        b4 = tf.Variable(tf.constant(0.1, dtype=tf.float32, shape=[OUTPUT_DIM]))

        h_layer = tf.nn.relu(tf.nn.dropout(tf.matmul(self.x_input, w1) + b1, KEEP_PROB))
        h_layer2 = tf.nn.relu(tf.nn.dropout(tf.matmul(h_layer, w2) + b2, KEEP_PROB))
        h_layer3 = tf.nn.relu(tf.matmul(h_layer2, w3) + b3)
        self.y = tf.nn.softmax(tf.matmul(h_layer3, w4) + b4)

    def build_loss(self):
        ce = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=self.y, labels=self.target)
        self.loss = tf.reduce_sum(ce)  # tf.reduce_mean()
        self.train_op = tf.train.AdamOptimizer(self.learning_rate).minimize(self.loss, global_step=self.train_step)

    def train(self):
        step = self.sess.run(self.train_step)
        batch = self.get_a_train_batch(step)
        data, label = self.get_data_label(batch)

        _, y = self.sess.run([self.train_op, self.y], feed_dict={self.x_input: data, self.target: label})
        if (step + 1) % 1000 == 0:
            # print(label)
            curr_loss, y = self.sess.run([self.loss, self.y], feed_dict={self.x_input: data, self.target: label})
            # print(y[0])
            print('trained {} rounds, current loss: {}'.format(step + 1, curr_loss))
            self.saver.save(self.sess, os.path.join(MODEL_SAVE_PATH, MODEL_NAME), global_step=step + 1)

    def get_a_train_batch(self, step):
        step = step % int(self.train_length / BATCH_SIZE)
        min = step * BATCH_SIZE
        max = min + BATCH_SIZE - 1
        return self.train_data[int(min):int(max + 1)]

    def get_data_label(self, batch):
        data = np.delete(batch, -1, axis=1)
        label = np.array(batch, dtype=np.int32)[:, -1]
        return data, label

    def init_data(self):
        self.train_data = []
        self.test_data = []  # init train and test data
        self.label_status = {}
        filename = 'train_data.csv'
        csv_reader = csv.reader(open(filename))
        label0_data = []
        label1_data = []
        label2_data = []
        label3_data = []
        label4_data = []
        for row in csv_reader:
            data = []
            for char in row:
                if char == 'None':
                    data.append(0)
                else:
                    data.append(np.float32(char))  # transform data from format of string to float32
            if data[-1] == 0:
                label0_data.append(data)
            if data[-1] == 1:
                label1_data.append(data)
            if data[-1] == 2:
                label2_data.append(data)
            if data[-1] == 3:
                label3_data.append(data)
            if data[-1] == 4:
                label4_data.append(data)
            if self.label_status.get(str(int(data[-1])), 0) > 0:
                self.label_status[str(int(data[-1]))] += 1
            else:
                self.label_status[str(int(data[-1]))] = 1
        while len(label0_data) < 10000:
            label0_data = label0_data + label0_data
        label0_data = random.sample(label0_data, 10000)
        while len(label1_data) < 10000:
            label1_data = label1_data + label1_data
        label1_data = random.sample(label1_data, 10000)
        while len(label2_data) < 10000:
            label2_data = label2_data + label2_data
        label2_data = random.sample(label2_data, 10000)
        while len(label3_data) < 10000:
            label3_data = label3_data + label3_data
        label3_data = random.sample(label3_data, 10000)
        while len(label4_data) < 10000:
            label4_data = label4_data + label4_data
        label4_data = random.sample(label4_data, 10000)
        self.train_data = label0_data + label1_data + label2_data + label3_data + label4_data
        filename = 'test_data.csv'
        csv_reader = csv.reader(open(filename))
        for row in csv_reader:
            data = []
            for char in row:
                if char == 'None':
                    data.append(0)
                else:
                    data.append(np.float32(char))  # transform data from format of string to float32
            self.test_data.append(data)
        self.train_length = len(self.train_data)
        self.test_length = len(self.test_data)
        self.train_data = self.normalization(self.train_data)
        self.test_data = self.normalization(self.test_data)
        np.random.shuffle(self.train_data)
        print('init data completed!')

    def normalization(self, minibatch):
        data = np.delete(minibatch, -1, axis=1)
        labels = np.array(minibatch, dtype=np.int32)[:, -1]
        mmax = np.max(data, axis=0)
        mmin = np.min(data, axis=0)
        for i in range(len(mmax)):
            if mmax[i] == mmin[i]:
                mmax[i] += 0.000001  # avoid getting devided by 0
        res = (data - mmin) / (mmax - mmin)
        res = np.c_[res, labels]
        return res

    def predict(self, x_feature):
        predict = self.sess.run(self.y, feed_dict={self.x_input: [x_feature]})[0]
        classLabel = np.argmax(predict)
        return classLabel

    def test(self):
        length = len(self.test_data)
        rightNum = 0
        np.random.shuffle(self.test_data)
        for row in self.test_data:
            feature = row[0:-1]
            label = row[-1]
            x_feature = np.array(feature)
            classLabel = self.predict(x_feature)
            if label == classLabel:
                rightNum += 1
        accuracy = rightNum / length
        return accuracy


if __name__ == '__main__':
    tf = tf.compat.v1
    tf.disable_v2_behavior()
    dnn = DNN()
    print('the number of training data: ', dnn.train_length)
    print('the number of test data: ', dnn.test_length)
    print('the training data status : ', dnn.label_status)
    print('start training...')
    for i in range(dnn.train_start, 20000):
        dnn.train()
    print('start testing...')
    accuracy = dnn.test()
    per = accuracy * 100
    print('the accuracy on test data:  ', '%.4f' % (per), '%')
